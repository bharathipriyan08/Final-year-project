import React from 'react';
import './ProcessList.css';

const ProcessList = ({ processes }) => {
  return (
    <div>
      <h2>Process List</h2>
      <table border="1" style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr>
            <th>PID</th>
            <th>Process Name</th>
            <th>Source IPs</th>
            <th>Legitimate Destination IPs</th>
            <th>Suspicious Destination IPs</th>
            <th>Network Packets</th>
          </tr>
        </thead>
        <tbody>
          {processes.map((process, index) => (
            <tr key={index}>
              <td>{process.PID}</td>
              <td>{process.ProcessName}</td>
              <td>{process.SourceIPs.join(', ')}</td>
              <td>{process.LegitimateDestinationIPs.join(', ')}</td>
              <td>{process.SuspiciousDestinationIPs.join(', ')}</td>
              <td>{process.NetworkPackets}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ProcessList;
