import React, { useEffect, useState } from 'react';
import ProcessList from './ProcessList';

const App = () => {
  const [processes, setProcesses] = useState([]);

  // Fetch data from Flask API
  const fetchData = () => {
    fetch('http://localhost:5000/api/processes') // Flask server URL
      .then(response => response.json())
      .then(data => setProcesses(data))
      .catch(error => console.error('Error fetching processes:', error));
  };

  useEffect(() => {
    fetchData(); // Initial data fetch

    // Polling every 50 seconds for updates
    const interval = setInterval(fetchData, 50000);

    return () => clearInterval(interval); // Cleanup on unmount
  }, []);

  return (
    <div>
      <h1>Process Monitor</h1>
      <ProcessList processes={processes} />
    </div>
  );
};

export default App;
