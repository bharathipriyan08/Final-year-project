from flask import Flask, jsonify
from flask_cors import CORS
import csv

app = Flask(__name__)
CORS(app)  # Enable CORS for cross-origin requests

def read_process_data():
    processes = []
    with open('process_network_details.csv', 'r') as file:  # Assuming the data is in CSV format
        reader = csv.reader(file)
        next(reader)  # Skip header
        for row in reader:
            processes.append({
                "PID": int(row[0]),
                "ProcessName": row[1],
                "SourceIPs": eval(row[2]),  # Convert string to list
                "LegitimateDestinationIPs": eval(row[3]),
                "SuspiciousDestinationIPs": eval(row[4]),
                "NetworkPackets": int(row[5])
            })
    return processes

@app.route('/api/processes', methods=['GET'])
def get_processes():
    data = read_process_data()
    return jsonify(data)

if __name__ == '__main__':
    app.run(debug=True)
